#!/bin/bash
java -cp lib/eagledns.jar se.unlogic.eagledns.utils.PrimaryZones2DB $1 $2 $3 $4 $5