#!/bin/bash
java -jar lib/eagledns.jar 