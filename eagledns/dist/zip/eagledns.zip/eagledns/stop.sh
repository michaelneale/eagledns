#!/bin/bash
java -cp lib/eagledns.jar se.unlogic.eagledns.EagleManagerClient conf/config.xml localhost shutdown